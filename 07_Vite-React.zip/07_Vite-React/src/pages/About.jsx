import React from 'react'

function About() {
  return (
    <div>
      <h1 className='text-2xl font-bold'>This is our about Page</h1>
    </div>
  )
}

export default About
