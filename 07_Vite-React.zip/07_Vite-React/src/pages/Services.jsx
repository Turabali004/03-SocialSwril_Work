import React from 'react'

function Services() {
  return (
    <div>
      <h1 className='text-2xl font-bold'>This is our services Page</h1>
    </div>
  )
}

export default Services
